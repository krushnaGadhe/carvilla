<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/cars.css">


<div style="display: flex; width: 100%; background-color:rgb(42, 46, 84)">

    <div class="navElement" style="font-weight: bold; width: 20%;color: rgb(255, 255, 255);text-transform: uppercase;"> <a href="index.php"> Carvilla </a> </div>


    <div class="navElement">Service</div>
    <div class="navElement">Home</div>
    <div class="navElement" style="width: 15%;">Featured Cars</div>
    <div class="navElement">Old Cars</div>
    <div class="navElement">Brands</div>
    <div class="navElement" style="width: 20%;">Contact

        <?php
        session_start();
        print_r($_SESSION);
        ?>

        <button class="btn btn-danger w-50" style="margin-left:25px" onclick="redirectToLRegister();"> Register</button>

    </div>
</div>

<script>
    function redirectToLRegister() {
        window.location.href = "registration.php"
    }
</script>