<div class="container-fluid mt-4" style="background-color: #2A2E54;color: rgb(227, 227, 227);">
    <div class="row p-4" style="list-style: none;">
        <div class="col-3">
            <h1>CARVILLA</h1>
            <br>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Odio, commodi. Omnis ab molestiae libero reiciendis?</p>
            <br>
            <p>name@domain.com</p>
            <p>+1(222) 1234567890</p>
        </div>
        <div class="col-2">
            <h4>About Devloon</h4>
            <br>
            <li>Career</li>
            <li>Terms of service</li>
            <li>Privacy Policy</li>
        </div>
        <div class="col-2">
            <h4>Top Stories</h4>
            <br>
            <li>BMW</li>
            <li>Lamborgini</li>
            <li>Audi</li>
            <li>Nissan</li>
            <li>Tata</li>
        </div>
        <div class="col-2">
            <li class="mt-5">Ferrari</li>
            <li>Porsche</li>
            <li>Land Rover</li>
            <li>Astin Martin</li>
        </div>
        <div class="col-3">
            <h4>News Letter</h4>
            <p class="mt-4">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Iure, sit.</p>
            <input type="text" class="form-control">
        </div>

    </div>

</div>