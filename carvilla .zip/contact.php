<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <table width="100%" border="1px">
        <tr >
            <td align="center">
                <img src="map.jpeg" alt="" width="100%" height="100%">
            </td>
            <td>
                <h4> Meet Us</h4>
                <p><b>
                    Phone
                </b></p>
                <p>
                    +9534154313
                </p>
                <p><b>
                    Our Office
                </b></p>
                <p>
                    Lorem ipsum dolor sit amet consectetur.
                </p>

                <p><b>
                    Chat with us
                </b></p>

                <p>
                    Lorem ipsum dolor sit amet consectetur.
                </p>
            </td>
            <td>
                <h4>Get In Touch</h4>
                <p>Name</p>
            
                <input type="text">
            
                <p>Email</p>
                
                <input type="text">

                <p>How can we help</p>
                
                <textarea name="" id="" rows=""></textarea>
                
                <br>
                <button>Submit</button>
            
            

            </td>
        </tr>
         
    </table>
    
</body>
</html>